# Project 3: SQL Data Analysis

## Overview
This project uses SQL (MySQL Workbench) to analyze an e-commerce orders dataset of 1,200 orders. The goal was to extract business insights using `SELECT`, `WHERE`, `GROUP BY`, `ORDER BY`, `HAVING`, and aggregate functions (`COUNT`, `SUM`, `AVG`).

**Tool used:** MySQL Workbench 8.0
**Dataset:** `orders` table — 1,200 rows, 14 columns (OrderID, Date, CustomerID, Product, Quantity, UnitPrice, ShippingAddress, PaymentMethod, OrderStatus, TrackingNumber, ItemsInCart, CouponCode, ReferralSource, TotalPrice)
**Query file:** `data_analysis.sql`



## Key Insights

### 1. Overall performance *(see Q7_headline_kpis.png)*
- Total orders: **1,200**
- Gross revenue (all orders): **₹1,264,761.96**
- Average order value (all orders): **₹1,053.97**
- Units sold: **3,535**

### 2. Order completion is a major issue *(see Q8_net_revenue.png, Q11_orders_by_status.png, Q19_pct_orders_by_status.png)*
- Only **703 orders (58.6%)** actually completed successfully.
- **Cancelled (250) + Returned (247) = 497 orders (41.4%)** never generated real revenue.
- Net revenue after removing cancelled/returned orders: **₹745,088.05** — a gap of roughly **₹5.2 lakh** between gross and net revenue.
- **Cancelled orders alone account for ₹276,396** in lost potential revenue, the single biggest leak in the funnel.

### 3. Product performance is evenly spread *(see Q10_revenue_by_product.png, Q18_pct_revenue_by_product.png)*
- No single product dominates revenue — all 7 products fall in a tight **12%–15.5%** share of total revenue.
- Chair and Printer are essentially tied for the top spot (~15.47% each).
- Phone has the lowest share at 12.00%.
- This suggests a broad, balanced catalog rather than one hero product.

### 4. Payment method affects both value and risk *(see Q12_avg_order_value_by_payment.png, Q20_cancellation_rate_by_payment.png)*
- **Credit Card** has the highest average order value (₹1,127.55) but also the **highest cancellation rate (23.08%)**.
- **Debit Card** has the lowest average order value (₹1,001.56) and the lowest cancellation rate (18.97%).
- Higher-value orders paid by credit card may need stronger fraud/confirmation checks before shipping.

### 5. Tablets have a return problem *(see Q21_return_rate_by_product.png)*
- **Tablet has the highest return rate at 24.02%**, notably above the next-highest (Laptop at 22.54%).
- **Chair has the lowest return rate (15.73%)**.
- Tablets may have a quality, sizing, or expectation-mismatch issue worth investigating further.

### 6. Marketing channel performance *(see Q13_revenue_by_referral_source.png)*
- **Instagram** is the top referral source by both order volume (259 orders) and revenue (₹275,285.45).
- Email, Google, and Facebook are close behind and fairly balanced.
- Referral brings up the rear, but the gap across all five channels is modest — no channel is significantly underperforming.

### 7. Top spenders are one-time buyers, not repeat customers *(see Q22_top5_customers_by_spend.png)*
- The top 5 customers by total spend each placed exactly **one order** (ranging from ₹3,322.55 to ₹3,456.40).
- There's no visible repeat-purchase pattern among the highest spenders — the "top customers" are really just customers who happened to place one large order.
- This suggests an opportunity to build a repeat-purchase or loyalty strategy, since high-value customers aren't currently returning.


## Query Sections
| Section | Focus | Query count |
|---|---|---|
| 0 | Data exploration (row counts, distinct values) | 3 |
| 1 | `WHERE` filtering | 5 |
| 2 | `COUNT` / `SUM` / `AVG` aggregates | 3 |
| 3 | `GROUP BY` + `ORDER BY` | 4 |
| 4 | `HAVING` (filtering groups) | 2 |
| 5 | Percentage contribution (subqueries) | 2 |
| 6 | Business questions (cancellation rate, return rate, top customers) | 3 |

**Total: 22 queries**



## Files in this submission
- Screenshots (11 total, one per key insight):
  1. ![Q7](Q7_headline_kpis.png)
  2. ![Q8](Q8_net_revenue.png)
  3. ![Q10](Q10_revenue_by_product.png)
  4. ![Q11](Q11_orders_by_status.png)
  5. ![Q12](Q12_avg_order_value_by_payment.png)
  6. ![Q13](Q13_revenue_by_referral_source.png)
  7. ![Q18](Q18_pct_revenue_by_product.png)
  8. ![Q19](Q19_pct_orders_by_status.png)
  9. ![Q20](Q20_cancellation_rate_by_payment.png)
  10. ![Q21](Q21_return_rate_by_product.png)
  11. ![Q22](Q22_top5_customers_by_spend.png)


## Skills demonstrated
- Writing multi-clause SQL queries (SELECT, WHERE, GROUP BY, HAVING, ORDER BY)
- Using aggregate functions to summarize business metrics
- Handling NULLs vs blank strings correctly (COUNT behavior)
- Calculating percentage contributions using correlated subqueries
- Translating raw query output into business-relevant insights