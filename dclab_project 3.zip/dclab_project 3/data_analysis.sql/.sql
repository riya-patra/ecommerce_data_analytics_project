USE decodelabs_project3;

CREATE TABLE IF NOT EXISTS orders (
    OrderID         VARCHAR(30),
    `Date`          DATE,
    CustomerID      VARCHAR(30),
    Product         VARCHAR(50),
    Quantity        INT,
    UnitPrice       DECIMAL(10,2),
    ShippingAddress VARCHAR(255),
    PaymentMethod   VARCHAR(30),
    OrderStatus     VARCHAR(30),
    TrackingNumber  VARCHAR(40),
    ItemsInCart     INT,
    CouponCode      VARCHAR(30),
    ReferralSource  VARCHAR(30),
    TotalPrice      DECIMAL(12,2)
);

SELECT COUNT(*) FROM orders;
SELECT * FROM orders LIMIT 10;
SELECT DISTINCT PaymentMethod FROM orders;
SELECT DISTINCT OrderStatus FROM orders;
SELECT DISTINCT Product FROM orders;
-- Q1: all delivered orders
SELECT OrderID, CustomerID, Product, TotalPrice
FROM orders
WHERE OrderStatus = 'Delivered';

-- Q2: high-value orders, biggest first
SELECT OrderID, Product, Quantity, TotalPrice
FROM orders
WHERE TotalPrice >= 2000
ORDER BY TotalPrice DESC;

-- Q3: laptop orders paid by credit card
SELECT OrderID, CustomerID, TotalPrice
FROM orders
WHERE Product = 'Laptop' AND PaymentMethod = 'Credit Card';

-- Q4: orders that used a SAVE coupon
SELECT OrderID, CouponCode, TotalPrice
FROM orders
WHERE CouponCode LIKE 'SAVE%';

-- Q6: orders with no coupon applied
SELECT OrderID, Product, TotalPrice
FROM orders
WHERE CouponCode IS NULL OR CouponCode = '';
-- Q7: headline KPIs across all orders
SELECT COUNT(*) AS total_orders,
       SUM(TotalPrice) AS total_revenue,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value,
       SUM(Quantity) AS units_sold
FROM orders;

-- Q8: "real" revenue, excluding cancelled and returned orders
SELECT COUNT(*) AS completed_orders,
       SUM(TotalPrice) AS net_revenue,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders
WHERE OrderStatus NOT IN ('Cancelled', 'Returned');

-- Q9: COUNT(*) vs COUNT(column) — shows how NULLs/blanks are handled
SELECT COUNT(*) AS all_rows,
       COUNT(CouponCode) AS rows_with_coupon_value
FROM orders;
-- Q10: revenue and volume by product
SELECT Product,
       COUNT(*) AS orders,
       SUM(Quantity) AS units_sold,
       SUM(TotalPrice) AS revenue,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders
GROUP BY Product
ORDER BY revenue DESC;

-- Q11: orders by status
SELECT OrderStatus,
       COUNT(*) AS orders,
       SUM(TotalPrice) AS revenue
FROM orders
GROUP BY OrderStatus
ORDER BY orders DESC;

-- Q12: average order value by payment method
SELECT PaymentMethod,
       COUNT(*) AS orders,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders
GROUP BY PaymentMethod
ORDER BY avg_order_value DESC;

-- Q13: revenue by referral source
SELECT ReferralSource,
       COUNT(*) AS orders,
       SUM(TotalPrice) AS revenue
FROM orders
GROUP BY ReferralSource
ORDER BY revenue DESC;

-- Q16: products whose average order value is above 1000
SELECT Product,
       COUNT(*) AS orders,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders
GROUP BY Product
HAVING AVG(TotalPrice) > 1000
ORDER BY avg_order_value DESC;

-- Q17: referral channels with more than 200 completed orders
SELECT ReferralSource,
       COUNT(*) AS completed_orders,
       SUM(TotalPrice) AS revenue
FROM orders
WHERE OrderStatus IN ('Delivered', 'Shipped')
GROUP BY ReferralSource
HAVING COUNT(*) > 80
ORDER BY revenue DESC;

-- Q18: each product's share of total revenue
SELECT Product,
	SUM(TotalPrice) AS revenue,
    ROUND(100.0 * SUM(TotalPrice) / (SELECT SUM(TotalPrice) FROM orders), 2) AS pct_of_revenue
FROM orders
GROUP BY Product
ORDER BY pct_of_revenue DESC;

-- Q19: each order status's share of all orders
SELECT OrderStatus,
       COUNT(*) AS orders,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM orders), 2) AS pct_of_orders
FROM orders
GROUP BY OrderStatus
ORDER BY pct_of_orders DESC;

-- Q20: cancellation rate by payment method
SELECT PaymentMethod,
       COUNT(*) AS total_orders,
       SUM(CASE WHEN OrderStatus = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled,
       ROUND(100.0 * SUM(CASE WHEN OrderStatus = 'Cancelled' THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancel_rate_pct
FROM orders
GROUP BY PaymentMethod
ORDER BY cancel_rate_pct DESC;

-- Q21: return rate by product
SELECT Product,
       COUNT(*) AS total_orders,
       ROUND(100.0 * SUM(CASE WHEN OrderStatus = 'Returned' THEN 1 ELSE 0 END) / COUNT(*), 2) AS return_rate_pct
FROM orders
GROUP BY Product
ORDER BY return_rate_pct DESC;

-- Q22: top 5 customers by spend (completed orders only)
SELECT CustomerID,
       COUNT(*) AS orders,
       SUM(TotalPrice) AS total_spent
FROM orders
WHERE OrderStatus NOT IN ('Cancelled', 'Returned')
GROUP BY CustomerID
ORDER BY total_spent DESC
LIMIT 5;