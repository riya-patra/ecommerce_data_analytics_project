# Project 2: Exploratory Data Analysis (EDA)

## Problem
Understand order patterns, revenue distribution, and operational risk in an
e-commerce orders dataset (1,200 orders, 14 columns) to surface insights a
business stakeholder can act on.

## Method
- Loaded the dataset with pandas and converted the Excel serial Date column
  to proper datetime.
- Computed descriptive statistics (mean, median, count) for all numeric
  columns using `describe()`.
- Detected outliers in TotalPrice using the IQR method (1.5×IQR rule).
- Grouped data by month, product, and referral source to identify trends.
- Visualized distribution, spread, and category performance with a
  histogram, boxplot, and bar chart.

## Key Findings

**41.4% of orders never complete — the single biggest business risk.**
Cancelled (250) and Returned (247) orders together account for 497 of 1,200
orders. Only 231 orders (19.25%) were fully Delivered.

**Order values are right-skewed — the median tells the real story.**
Mean TotalPrice is ₹1,053.97, but median is ₹823.62. The gap is caused by a
small number of high-value orders, not a "typical" order being that
expensive. The distribution chart confirms a long right tail out to ₹3,500.

**8 outlier orders are genuine bulk purchases, not data errors.**
All 8 flagged orders (above ₹3,330.41) are maximum-quantity (5) purchases of
higher-priced items like Printers, Laptops, and Tablets — classified as
signal, not noise. UnitPrice itself has no outliers, confirming these are
driven by quantity × price combinations.

**Chair and Printer drive the most revenue; Phone lags behind.**
Despite Printer having more individual orders (181) than Chair (178), Chair
edges out slightly on total revenue (~₹195K each), suggesting a higher
average order value for Chairs. Phone is the weakest performer on both
order count (156) and total revenue (~₹150K).

**~26% of orders have no coupon applied.**
CouponCode is missing in 309 of 1,200 rows — this reflects orders placed
without a promo code, not a data quality issue. All other fields are fully
populated.

## Recommendation
Investigate the causes behind the 41.4% cancellation/return rate first —
even a modest reduction here recovers more revenue than any single product
or marketing optimization. Secondary priority: review why Phone
underperforms relative to other products despite similar pricing tiers.

## Files
- `dcl_p2.py` — analysis script
- ![TotalPrice distribution](totalprice_distribution.png) -histogram of order values
- ![UnitPrice_boxplot](unitprice_boxplot.png) — outlier check on unit price
- ![sales_by_product](sales_by_product.png) — revenue by product category