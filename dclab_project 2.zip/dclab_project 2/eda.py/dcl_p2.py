import pandas as pd
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# 1. LOAD THE DATA
# ------------------------------------------------------------
df = pd.read_excel(r"C:\Users\USER\OneDrive\Attachments\dclab project\dclab_project 2\Dataset for Da2.xlsx")
print("Shape:", df.shape)
print(df.head())
print(df.dtypes)

# ------------------------------------------------------------
# 2. FIX THE DATE COLUMN (if it's still an Excel serial number)
# ------------------------------------------------------------
if pd.api.types.is_numeric_dtype(df["Date"]):
    df["Date"] = pd.to_datetime(df["Date"], origin="1899-12-30", unit="D")

# ------------------------------------------------------------
# 3. BASIC STATISTICS (mean, median, count)
# ------------------------------------------------------------
print("\n--- Numeric summary ---")
print(df.describe())

print("\n--- Product counts ---")
print(df["Product"].value_counts())

print("\n--- Order status counts ---")
print(df["OrderStatus"].value_counts())

print("\n--- Payment method counts ---")
print(df["PaymentMethod"].value_counts())

print("\n--- Missing values ---")
print(df.isnull().sum())

# ------------------------------------------------------------
# 4. OUTLIER DETECTION (IQR method) on TotalPrice
# ------------------------------------------------------------
Q1 = df["TotalPrice"].quantile(0.25)
Q3 = df["TotalPrice"].quantile(0.75)
IQR = Q3 - Q1
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

outliers = df[(df["TotalPrice"] < lower) | (df["TotalPrice"] > upper)]
print(f"\n--- Outliers in TotalPrice ---")
print(f"Lower bound: {lower:.2f}, Upper bound: {upper:.2f}")
print(f"Number of outlier orders: {len(outliers)}")
print(outliers[["OrderID", "Product", "Quantity", "TotalPrice"]].head(10))

# ------------------------------------------------------------
# 5. TRENDS
# ------------------------------------------------------------
print("\n--- Monthly sales trend ---")
monthly_sales = df.groupby(df["Date"].dt.to_period("M"))["TotalPrice"].sum()
print(monthly_sales)

print("\n--- Sales by product ---")
sales_by_product = df.groupby("Product")["TotalPrice"].sum().sort_values(ascending=False)
print(sales_by_product)

print("\n--- Sales by referral source ---")
sales_by_referral = df.groupby("ReferralSource")["TotalPrice"].sum().sort_values(ascending=False)
print(sales_by_referral)

cancelled_returned_pct = df["OrderStatus"].isin(["Cancelled", "Returned"]).mean() * 100
print(f"\n% of orders Cancelled/Returned: {cancelled_returned_pct:.1f}%")

# ------------------------------------------------------------
# 6. VISUALIZATIONS
# ------------------------------------------------------------
plt.figure()
df["TotalPrice"].hist(bins=30)
plt.title("Distribution of TotalPrice")
plt.xlabel("TotalPrice")
plt.ylabel("Number of Orders")
plt.savefig("totalprice_distribution.png")

plt.figure()
df.boxplot(column="UnitPrice")
plt.title("UnitPrice Boxplot (outlier check)")
plt.savefig("unitprice_boxplot.png")

plt.figure()
sales_by_product.plot(kind="bar")
plt.title("Total Sales by Product")
plt.ylabel("TotalPrice")
plt.tight_layout()
plt.savefig("sales_by_product.png")

print("\nCharts saved: totalprice_distribution.png, unitprice_boxplot.png, sales_by_product.png")

# ------------------------------------------------------------
# 7. KEY OBSERVATIONS 
# ------------------------------------------------------------
print("\n--- SUMMARY ---")

print("1. 41.4% of orders never complete: Cancelled (250) + Returned (247) = "
      "497 of 1,200 orders. Only 231 orders (19.25%) were fully Delivered. "
      "This is the single biggest business risk in the dataset.")

print("2. Order values are right-skewed: Mean TotalPrice is Rs.1,053.97, but "
      "median is Rs.823.62. The gap is caused by a small number of high-value "
      "orders, not a 'typical' order being that expensive. The distribution "
      "chart confirms a long right tail out to Rs.3,500.")

print("3. 8 outlier orders are genuine bulk purchases, not data errors: All 8 "
      "flagged orders (above Rs.3,330.41) are maximum-quantity (5) purchases "
      "of higher-priced items like Printers, Laptops, and Tablets. UnitPrice "
      "itself has no outliers, confirming these are driven by quantity x "
      "price combinations.")

print("4. Chair and Printer drive the most revenue; Phone lags behind: "
      "Despite Printer having more individual orders (181) than Chair (178), "
      "Chair edges out slightly on total revenue (~Rs.195K each), suggesting "
      "a higher average order value for Chairs. Phone is the weakest "
      "performer on both order count (156) and total revenue (~Rs.150K).")

print("5. ~26% of orders have no coupon applied: CouponCode is missing in "
      "309 of 1,200 rows, reflecting orders placed without a promo code, "
      "not a data quality issue. All other fields are fully populated.")

print("\nRecommendation: Investigate the causes behind the 41.4% "
      "cancellation/return rate first, since even a modest reduction here "
      "recovers more revenue than any single product or marketing "
      "optimization. Secondary priority: review why Phone underperforms "
      "relative to other products despite similar pricing tiers.")